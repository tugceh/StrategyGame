﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Nodes : MonoBehaviour
{
    public Point GridPosition { get; private set; }

    public TileScript TileRef { get; private set; }
    public Nodes(TileScript tileref)
    {
        this.TileRef = tileref;
        this.GridPosition = tileref.GridPosition;
    }
}
