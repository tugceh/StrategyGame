﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public  static class Astar
{
    private static Dictionary<Point, Nodes> node;
    private static void CreateNodes()
    {
        node = new Dictionary<Point, Nodes>();
        foreach (TileScript tile in LevelManager.Instance.Tiles.Values)
        {
            node.Add(tile.GridPosition,new Nodes(tile));
        }
    }
}
