﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameManager : Singleton<GameManager>
{
    public GameObject barrackPrefab;

    public GameObject BarrackPrefab
    {
        get
        {
            return barrackPrefab;
        }
    }
    
   
}
