﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SelectItems : MonoBehaviour
{

    private void OnMouseOver()
    {
        if (Input.GetMouseButtonDown(0))
        {
            PlaceItem();
        }
    }

    private void PlaceItem()
    {

        //Instantiate(GameManager.Instance.BarrackPrefab,transform.position,Quaternion.identity);
    }
}
