﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MouseFollowing : MonoBehaviour
{
    public GameObject building;
	private GameObject pMenu;

	private Vector3 rawInput;
	private Vector3 roundedOutput;
	private Selecting sm;


	/// <summary>
	/// singleton
	/// </summary>
	public static MouseFollowing instance { get; private set; }

	private void Awake()
	{
		if (instance != null && instance != this)
			Destroy(this);
		else
			instance = this;
	}

	private void Start()
	{
		pMenu = CanvasManager.instance.productionMenu; // to disable the unit and building contols when build mode is used.
		sm = Selecting.instance; // to disable the unit and building contols when build mode is used.
	}

	private void Update()
	{
		if (building != null)
		{
			rawInput = Input.mousePosition;
			rawInput.z = building.transform.position.z - Camera.main.transform.position.z;
			roundedOutput = new Vector3(Mathf.RoundToInt(Camera.main.ScreenToWorldPoint(rawInput).x),
				Mathf.RoundToInt(Camera.main.ScreenToWorldPoint(rawInput).y),
				Mathf.RoundToInt(Camera.main.ScreenToWorldPoint(rawInput).z));
			building.transform.localPosition = roundedOutput;

			if (Input.GetMouseButtonDown(0))
				Drop();
			if (Input.GetMouseButtonDown(1))
				DestroyBuilding();
		}
	}

	public void Pick(GameObject b)
	{
		//Destroy(GameObject.Find("InformationMenu"));
		sm.enabled = false;
		building = b;
		pMenu.SetActive(false);
	}

	private void Drop()
	{
		if (building.GetComponentInChildren<Buildings>().dropCheck)
		{
			sm.enabled = true;
			building.GetComponentInChildren<Buildings>().updateGrid = true;
			building = null;
			pMenu.SetActive(true);
		}
	}

	public void DestroyBuilding()
	{
		if (building != null)
		{
			sm.enabled = true;
			Destroy(building);
			pMenu.SetActive(true);
		}
	}
}
