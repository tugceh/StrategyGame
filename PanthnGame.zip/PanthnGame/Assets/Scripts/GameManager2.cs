﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameManager2 : Singleton<GameManager2>
{
    public GameObject ppPrefab;

    public GameObject PpPrefab
    {
        get
        {
            return ppPrefab;
        }
    }
    

}

