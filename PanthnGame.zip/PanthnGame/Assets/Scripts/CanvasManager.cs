﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CanvasManager : MonoBehaviour
{
    //kullanmadımmm
	public GameObject informationMenu;

	public GameObject productionMenu;

	/// <summary>
	/// to access information and production menu easily, made it singleton
	/// </summary>
	public static CanvasManager instance { get; private set; }

	private void Awake()
	{
		if (instance != null && instance != this)
			Destroy(this);
		else
			instance = this;
	}
}
