﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class UIManager : MonoBehaviour
{
    [SerializeField] List<GameObject> buildMenus;
    public void ChangeGame(int i)
    {
        GameFuncs.ChangeMenu(buildMenus.ToArray(),i);
    }
}
