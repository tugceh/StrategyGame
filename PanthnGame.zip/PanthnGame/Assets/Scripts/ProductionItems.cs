﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ProductionItems : MonoBehaviour
{
    public GameObject Barracks;
    public void Spawn(Vector3 position)
    {
        Instantiate(Barracks).transform.position = position;
    }
   
    // Update is called once per frame
    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Mouse0))
        {
            Vector3 worldPoint = Camera.main.ScreenToWorldPoint(Input.mousePosition,Camera.MonoOrStereoscopicEye.Mono);

            Vector3 adjustZ = new Vector3(Barracks.transform.position.x, Barracks.transform.position.y,Barracks.transform.position.z);
            Spawn(adjustZ);
        }
    }

   /* private void OnMouseDown()
    {
        if (Input.GetMouseButtonDown(0))
        {
            GameObject newBarrack = (GameObject)Instantiate(Barracks) as GameObject;

            float x = Random.Range(-5,5);
            float y = Random.Range(-2,2);

            newBarrack.transform.position = new Vector2(x,y);
        }
    }*/
}
