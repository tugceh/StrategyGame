﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public abstract class Content : MonoBehaviour
{
    [SerializeField] internal GameObject prefab;

	public float startingPoint;

	internal abstract IEnumerator Fill();
}
