﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameFuncs : MonoBehaviour
{
    
    public static void ChangeMenu(GameObject[] gos,int index)
    {
        // Burası scrollview dan barracks veya pp ye tıkladığımızda sağ da gözükecek ve değişecek olan menü işlemleri için
        for (int i = 0; i < gos.Length; i++)
        {
            gos[i].SetActive(i == index ? true : false);
        }
    }
}
