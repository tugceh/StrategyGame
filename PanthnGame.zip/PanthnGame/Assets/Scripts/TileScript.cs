﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TileScript : MonoBehaviour
{
    public Point GridPosition { get; private set; }

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    public void Setup(Point gridPosition,Vector3 worldPos)
    {
        this.GridPosition = gridPosition;
        transform.position = worldPos;
        //LevelManager lm = GameObject.FindObjectOfType<LevelManager>();
        //lm.Tiles.Add(gridPosition, this);
        LevelManager.Instance.Tiles.Add(gridPosition, this);
    }

    private void OnMouseOver()
    {
        if (Input.GetMouseButtonDown(0))
        {
            PlaceTower();
        }
    }
    private void PlaceTower()
    {

        Instantiate(GameManager.Instance.BarrackPrefab,transform.position,Quaternion.identity);
        Instantiate(GameManager2.Instance.PpPrefab, transform.position, Quaternion.identity);
    }
}
