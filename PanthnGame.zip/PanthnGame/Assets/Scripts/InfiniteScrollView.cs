﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class InfiniteScrollView : MonoBehaviour
{

    public bool InitByUser = false;
    private ScrollRect _scrollRect;
    private ContentSizeFitter _contentSizeFitter;
    private VerticalLayoutGroup _verticalLayoutGroup;
    private HorizontalLayoutGroup _horizontalLayoutGroup;
    private GridLayoutGroup _gridLayoutGroup;
    private bool _isVertical = false;
    private bool _isHorizontal = false;
    private float _disableMarginX = 0;
    private float _disableMarginY = 0;
    private bool hasDisabledGridComponents = false;
    private List<RectTransform> items = new List<RectTransform>();

    void Awake()
    {
        if (InitByUser)
            return;

        Init();

    }

    public void Init()
    {
        if (GetComponent<ScrollRect>() != null)
        {
            _scrollRect = GetComponent<ScrollRect>();
            _scrollRect.onValueChanged.AddListener(OnScroll);

            //_isHorizontal = _scrollRect.horizontal;
            _isVertical = _scrollRect.vertical;

            for (int i = 0; i < _scrollRect.content.childCount; i++)
            {
                items.Add(_scrollRect.content.GetChild(i).GetComponent<RectTransform>());
            }
            if (_scrollRect.content.GetComponent<VerticalLayoutGroup>() != null)
            {
                _verticalLayoutGroup = _scrollRect.content.GetComponent<VerticalLayoutGroup>();
            }
            /*if (_scrollRect.content.GetComponent<HorizontalLayoutGroup>() != null)
            {
                _horizontalLayoutGroup = _scrollRect.content.GetComponent<HorizontalLayoutGroup>();
            }*/
            if (_scrollRect.content.GetComponent<GridLayoutGroup>() != null)
            {
                _gridLayoutGroup = _scrollRect.content.GetComponent<GridLayoutGroup>();
            }
            if (_scrollRect.content.GetComponent<ContentSizeFitter>() != null)
            {
                _contentSizeFitter = _scrollRect.content.GetComponent<ContentSizeFitter>();
            }

        }
        else
        {
            Debug.LogError("UI_ScrollRectOcclusion => No ScrollRect component found");
        }
    }

   void DisableGridComponents()
    {
        if (_isVertical)
            _disableMarginY = _scrollRect.GetComponent<RectTransform>().rect.height / 2 + items[0].sizeDelta.y;

        if (_verticalLayoutGroup)
        {
            _verticalLayoutGroup.enabled = false;
        }
        if (_contentSizeFitter)
        {
            _contentSizeFitter.enabled = false;
        }
        if (_gridLayoutGroup)
        {
            _gridLayoutGroup.enabled = false;
        }
        hasDisabledGridComponents = true;
    }
    
    public void OnScroll(Vector2 pos)
    {

        if (!hasDisabledGridComponents)
            DisableGridComponents();

        for (int i = 0; i < items.Count; i++)
        {
            if (_isVertical /*&& _isHorizontal*/)
            {
                if (_scrollRect.transform.InverseTransformPoint(items[i].position).y < -_disableMarginY || _scrollRect.transform.InverseTransformPoint(items[i].position).y > _disableMarginY
                || _scrollRect.transform.InverseTransformPoint(items[i].position).x < -_disableMarginX || _scrollRect.transform.InverseTransformPoint(items[i].position).x > _disableMarginX)
                {
                    items[i].gameObject.SetActive(false);
                }
                else
                {
                    items[i].gameObject.SetActive(true);
                }
            }
            else
            {
                if (_isVertical)
                {
                    if (_scrollRect.transform.InverseTransformPoint(items[i].position).y < -_disableMarginY || _scrollRect.transform.InverseTransformPoint(items[i].position).y > _disableMarginY)
                    {
                        items[i].gameObject.SetActive(false);
                    }
                    else
                    {
                        items[i].gameObject.SetActive(true);
                    }
                }

                /*if (_isHorizontal)
                {
                    if (_scrollRect.transform.InverseTransformPoint(items[i].position).x < -_disableMarginX || _scrollRect.transform.InverseTransformPoint(items[i].position).x > _disableMarginX)
                    {
                        items[i].gameObject.SetActive(false);
                    }
                    else
                    {
                        items[i].gameObject.SetActive(true);
                    }
                }*/
            }
        }
    }


}
