﻿using UnityEngine;
using UnityEngine.Events;

public class HSVChangedEvent : UnityEvent<float, float, float>
{

}
