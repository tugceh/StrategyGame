using System;
namespace UnityEngine.UI.Extensions
{
    public class DontSaveField : Attribute
    {

    }
}